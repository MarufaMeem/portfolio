<?php
    $connection=mysqli_connect('localhost','root','','reg_db_b2');
        if(!$connection){
            die("Connection failed!: ".mysqli_connect_error());
        }
    $del_id=$_REQUEST['id'];
    $delete_query= "delete from reg_table where id=$del_id";
    $delete =mysqli_query($connection,$delete_query);
    if($delete){
        header("location: view.php");
    }
// Write your code to delete data
?>