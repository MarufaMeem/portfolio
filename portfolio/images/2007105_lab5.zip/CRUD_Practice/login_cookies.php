<?php
if (isset($_COOKIE['loggedin'])) {
    header("Location: welcome.php"); // Redirect to welcome page if user is already logged in
    exit();
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate username and password against database

    $connection = mysqli_connect('localhost', 'root', '', 'reg_db_b2');
    if (!$connection) {
        die("Connection failed!: " . mysqli_connect_error());
    }

    $check_query = "SELECT * FROM reg_table WHERE username='$username' and password='$password'";
    $result = mysqli_query($connection, $check_query);

    if (mysqli_num_rows($result) == 0) {
        echo "No such username or password is found";
        exit(); // Stop further execution
    }

    /*Cookies are set for 1hour for testing purpose*/
    setcookie('username',$username, time() + 3600, "/");
    setcookie('loggedin', true, time() + 3600, "/");
    header("Location: welcome.php"); // Redirect to welcome page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>

<body>
    <h2>Login</h2>
    <form action="login_cookies.php" method="POST">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" name="submit" value="Login">
    </form>
</body>

</html>