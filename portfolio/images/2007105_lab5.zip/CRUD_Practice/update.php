<?php

// Write your code to update data
    $connection = mysqli_connect('localhost', 'root', '', 'reg_db_b2');
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        if(isset($_POST['submit'])) {
            $u_name = $_POST['username'];
            $u_email= $_POST['email'];
            $u_password= $_POST['password'];
            $u_id= $_POST['id'];

            $update_query ="update reg_table set username='$u_name', email='$u_email', password='$u_password' where id='$u_id'";
            $update= mysqli_query($connection,$update_query);
            if($update){
                header("location: view.php");
            }

        }

?>

