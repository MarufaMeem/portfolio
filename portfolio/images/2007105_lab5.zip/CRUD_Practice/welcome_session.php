<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: login_session.php"); // Redirect to login page if user is not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>

<body>
    <h2>Welcome!</h2>
    <h3>You are now logged in.</h3>
    <h4>Hello, <?php echo $_SESSION['username'] ?></h4>
    <a href="logout_session.php">Logout</a> <!-- Logout link -->
</body>

</html>