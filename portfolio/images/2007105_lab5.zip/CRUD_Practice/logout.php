<?php
setcookie('loggedin','',time()-5,'/');
header("Location: login_cookies.php");
?>